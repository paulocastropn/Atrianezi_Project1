// Naming convention for models: use singular form of the represented entity
// Import mongoose
const mongoose = require("mongoose");
// Define data schema (JSON)
const dataSchemaObj = {
  name: { type: String, required: true },
  sku: { type: String, required: true },
  collection: { type: String, required: true },
  stock: { type: Number, required: true },
};
// Create mongoose schema
const productSchema = mongoose.Schema(dataSchemaObj);
// Create and import mongoose model
module.exports = mongoose.model("product", productSchema);