const express = require("express");
const router = express.Router();
// Change the import name from "Course" to "Collection"
const Collection = require("../models/collection");
const AuthenticationMiddleware = require("../extensions/authentication");

// GET /Courses/
router.get("/", async (req, res, next) => {
  let collection = await Collection.find().sort([["name", "ascending"]]); // Use Collection here
  res.render("collection/index", { title: "Our Collections", dataset: collection, user: req.user });
});

// GET /Courses/Add
router.get("/add", AuthenticationMiddleware, (req, res, next) => {
  res.render("collection/add", { title: "Add a new Collection", user: req.user });
});


// POST /Courses/Add
router.post("/add", AuthenticationMiddleware, async (req, res, next) => {
  let newCollection = new Collection({  // Use Collection here
    name: req.body.name,
    code: req.body.code,
  });
  await newCollection.save();
  res.redirect("/collection");
});

module.exports = router;
